# 와이어프레임 캔버스 제작 규칙

STEP 4에서 사용한다. 목적은 **상세페이지 구조와 카피 확인**이다. 색·사진·장식은 넣지 않는다. 먼저 `detailpage-anatomy.md`를 읽고, 모듈은 `modules.md`에서 고른다.

## 0. 반드시 지킬 규칙

1. **상세페이지처럼 보이게 만든다.** 웹 화면(버튼, 격자 카드, 여백 있는 블록)이 아니라 참고 상세페이지처럼 만든다.
   - 섹션 아트보드를 **간격 0으로 이어 붙인다**(y = 이전 y + 이전 h). 한 장의 긴 상세페이지로 보여야 한다.
   - 배경을 **회색 톤으로 교대**한다: 흰(#fff) / 연회색(#f1f1f1) / 중간(#dcdcdc) / 진한(#222, 흰 글씨) / 전체 이미지(#111, 흰 글씨).
   - 모든 섹션은 **라벨 → 제목(키워드 강조 박스) → 서브·본문 1~2줄 → 비주얼 모듈 → 각주** 틀을 따르고, 한 섹션에 **모듈 2~4개**를 넣는다.
   - 화면의 절반 이상은 이미지 자리(검은 박스)로 채운다.
   - 웹 UI 요소(버튼, 입력창, 격자 표)를 쓰지 않는다. 구매 유도는 **가로 띠 배너**(검은 바 + 흰 글씨).
2. 아트보드 **가로 860px 고정, 세로는 항상 가로보다 길게(최소 1200px)**. 정사각형·가로형 금지. 위에서부터 채우고 내용이 모자라면 비주얼 모듈을 늘린다(세로 가운데 정렬로 빈 공간을 만들지 않는다).
3. **좌우 여백 40px**(본문 폭 780px).
4. **글자 크기는 22px ~ 82px 범위 안에서만** 쓴다: 82(비주얼 섹션 제목) / 64(정보 섹션 제목) / 48(긴 제목, 강조 메시지) / 32(서브, 소제목) / 26(본문) / 22(가장 작은 글씨: 수치·출처·각주·라벨).
5. **섹션 제목은 가운데 정렬**.
6. **이미지 자리는 검은색 박스(#111)** + 흰 글씨(22px)로 "무슨 이미지인지" 적는다. 점선·회색 박스 금지.
7. **비주얼 섹션**(Hero, Brand, 대형 문구 Point)은 **섹션 전체 배경이 연출 이미지**: 아트보드 전체를 검은색으로 깔고 왼쪽 위에 `[BG IMG] 전체 배경 연출 이미지 · 설명` 라벨, 글자는 흰색.
8. **카피는 채워서 만든다.** 비어 있는 것은 사실 정보 자리표시(`[실제 … 입력]`, `[근거 확인]`)뿐이다.
9. **신뢰 근거**: 순위·특허·판매 규모 같은 메시지 문구는 48px 굵게 강조하고, 실제 수치·출처·기준 시점은 22px로 쓴다.
10. 색은 흑·백·회색만. 폰트는 Noto Sans KR(와이어프레임용).

## 1. 형식 선택 (우선순위)

1. **Design(캔버스) 유형** — `Artifact`로 `action:"list", scope:"types"`를 호출해 있는지 확인. 있으면 `action:"read"`로 그 유형의 안내를 읽고 그 형식과 절차를 따른다. 이 문서는 내용 규칙만 정한다.
   - **아트보드는 직접 손으로 짜지 말고 `scripts/build_canvas.py`로 만든다.** 같은 스펙(6번)이면 항상 같은 규칙(이어 붙임, 회색 톤 교대, 모듈 틀, 글자 22~82px, 검은 이미지 박스)으로 나온다.
     ```
     python scripts/build_canvas.py spec.json <출력 루트 폴더>
     ```
     `<루트>/project/`에 아트보드와 `canvas.json`이 생기고, 보드 높이는 모듈 높이로 계산한다(1200 이상). 만든 파일을 Design 유형의 절차대로 올린다(한 번에 15개 이내, `canvas.json`은 마지막). 이미 캔버스가 있으면 루트에 읽어 온 `project/canvas.json`을 두면 내 키만 갱신한다.
   - 생성기에 없는 모듈이 필요하면 `modules.md`의 인라인 스타일로 그 섹션만 직접 작성한다.
2. **Figma** — Design 유형이 없고 Figma 연결이 있으며 사용자가 원할 때. 섹션 1개 = 프레임 1개(가로 860).
3. **폴백 HTML** — 둘 다 없을 때 `scripts/build_wireframe.py`. 섹션이 이어 붙은 한 장의 페이지가 나오고 글자를 클릭해 수정할 수 있다.
   ```
   python scripts/build_wireframe.py spec.json /mnt/user-data/outputs/wireframe.html
   ```
   스펙은 6번. 결과는 Artifact `publish` 또는 `present_files`로 전달한다.

사용자에게는 "섹션별 캔버스가 만들어졌고 글자를 클릭해 바로 수정할 수 있다"고만 말한다. 내부 파일 구조는 설명하지 않는다.

## 2. Design 캔버스 배치

- 섹션 1개 = 아트보드 1개. 첫 아트보드는 `Main.dc.html`, 나머지는 `s02-trust.dc.html`처럼 순번-유형 이름.
- 보드: `w` = 860, `h` = 1200 이상. **세로 한 줄로 간격 0으로 쌓는다**: `x` = 0, `y` = 이전 y + 이전 h.
- 주석 스티커(`notes`): 각 보드 오른쪽 `x` = 940, 보드 `y`와 같은 위치, `w` = 300. 내용: `P번호 유형 / 목적 / 입력 필요`.
- 보드 `title`은 `P3 Pain · 정보` 형태.
- 파일은 15개 이내로 묶어 보낼 수 있다(`canvas.json`은 마지막). 사용자가 요청하지 않으면 렌더링으로 확인하지 않는다.

## 2-1. 섹션을 나중에 추가·삭제할 때

- 기존 파일 이름은 바꾸지 않는다. 새 아트보드는 `s08b-maker.dc.html`처럼 접미사를 붙인 새 이름으로 만든다.
- 번호(P1…Pn)는 `canvas.json`의 보드 `title`과 스티커 글자에서만 다시 매기고, `y`는 새 순서로 다시 계산한다(간격 0).
- 수정 전에 `canvas.json`을 다시 읽어 사용자가 직접 바꾼 값은 유지하고 내 키만 바꾼다.
- 아트보드 삭제는 사용자에게 캔버스에서 직접 지워 달라고 안내한다.

## 3. 아트보드 마크업 원칙

- 루트는 가로 860px 고정, 세로 px 지정, `box-sizing:border-box`, 위에서부터 채우는 세로 flex(`justify-content:flex-start`), 간격 32px, 패딩 `80px 40px`.
- 속성은 **인라인 `style`**. 문구는 **그대로 글자로** 적는다(`{{…}}` 변수 금지). 줄바꿈은 `white-space:pre-line`.
- 이모지 금지. 링크가 필요하면 `<a href="#">`. 구매 유도는 띠 배너(div).
- 글자색 대비 4.5:1 이상. 흰 배경 보조 글자는 `#555` 이상, 검은 배경은 `#fff`.
- 헤드: `<helmet>`에 Noto Sans KR `<link>`와 `body{margin:0}`.

```html
<div style="width:860px;height:1500px;box-sizing:border-box;padding:80px 40px;background:#f1f1f1;color:#111;font-family:'Noto Sans KR',sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:32px">
  <div style="font-size:22px;font-weight:700;letter-spacing:.06em;border:2px solid #111;border-radius:999px;padding:4px 22px">POINT 01</div>
  <h2 style="margin:0;width:100%;text-align:center;font-size:64px;line-height:1.25;font-weight:800;white-space:pre-line">가방에 쏙
들어가는 <span style="background:#cdcdcd;padding:0 8px">크기</span></h2>
  <div style="width:780px;height:780px;background:#111;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;box-sizing:border-box;font-size:22px">[IMG] 가방 속 제품 컷 · 1:1</div>
  <p style="margin:0;font-size:26px;line-height:1.6;color:#333">[크기 설명 입력]</p>
</div>
```

비주얼 섹션 루트는 `position:relative;background:#111;color:#fff;justify-content:center;padding:120px 40px`에 왼쪽 위 `[BG IMG]` 라벨(흰 바탕, 22px)을 더한다.

## 4. 섹션별 높이 시작값 (모듈을 채운 뒤 조정)

| 유형 | 시작 높이 | 유형 | 시작 높이 |
|---|---|---|---|
| Hero | 1400 | Review | 1300 |
| Trust | 1300 | Why | 1200 |
| Pain | 1500 | Brand | 1400 |
| Cause | 1300 | Info | 1800 |
| Point | 1400~1600 | Notice | 1200 |
| Proof | 1600 | Maker | 1500 |
| How-to | 1800 | | |

잘리는 것보다 넉넉한 쪽이 낫다. 모듈 높이는 `modules.md`의 이미지 높이표로 계산한다.

## 5. 점검 (만든 뒤 스스로 확인)

- [ ] 보드 간격이 0이고 한 장의 페이지처럼 이어지는가
- [ ] 배경이 회색 톤으로 교대하고 비주얼 섹션은 전체 이미지인가
- [ ] 섹션마다 라벨/제목/문구/비주얼/각주 틀과 모듈 2~4개가 있는가
- [ ] 이미지 비중이 절반 이상이고 웹 버튼이 없는가
- [ ] 가로 860, 세로 1200 이상, 여백 40, 글자 22~82px인가

## 6. 폴백 스펙(JSON)

```json
{
  "title": "제품명 상세페이지 와이어프레임",
  "brand": "브랜드명",
  "sections": [
    {"type":"hero","bg_label":"연출 컷 설명","theory":"후크","goal":"목적",
     "blocks":[{"m":"headline","size":"xl","text":"문구\n**강조**"},{"m":"sub","text":"서브"}]}
  ]
}
```
- 섹션: `type`(hero, trust, pain, cause, point, proof, howto, review, why, brand, info, notice, maker), `bg`(bg0·bg1·bg2·dark, 비주얼은 자동 전체 이미지), `bg_label`, `theory`, `goal`, `note`, `blocks`, `file`(선택: 아트보드 파일명 고정)
- **이미 올린 캔버스에 섹션을 끼워 넣을 때**: 기존 섹션에는 현재 파일명을 `file`로 그대로 적고, 새 섹션에는 `s08b-maker.dc.html`처럼 새 이름을 적는다. 생성기는 `<루트>/project/canvas.json`이 있으면 그것을 읽어 P번호·`y`·주석 스티커를 다시 매기고, 내용이 바뀐 파일과 새 파일, `canvas.json`(마지막)만 올리면 된다. 파일명을 고정하지 않으면 순번이 밀려 쓰지 않는 옛 파일이 캔버스에 남는다.
- 블록: `{"m":"모듈이름", …}` — 모듈 이름과 필드는 `modules.md`
- 문자열 안의 `[실제 … 입력]`, `[… 확인]`은 "입력 필요"로 자동 집계된다.
